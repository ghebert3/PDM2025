function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB);
  angleMode(DEGREES)
}

function draw() {
  background(150,255,100);
  fill(200,0,200)
  square(700, 200, 110)

  fill(200,0,200)
  circle(600, 250, 130)

  fill(0,0,100) 



}  